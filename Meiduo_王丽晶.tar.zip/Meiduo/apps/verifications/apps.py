from django.apps import AppConfig


class VerificationsConfig(AppConfig):
    name = 'apps.verifications'
