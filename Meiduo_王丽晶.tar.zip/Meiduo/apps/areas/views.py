from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render
from django.views import View

from apps.areas.models import Area


class AddressView(LoginRequiredMixin, View):
    """收货地址页"""

    def get(self, request):
        return render(request, 'user_center_site.html')


class AreasView(View):
    """ 获取省 市 区县数据"""

    def get(self, request):
        # 请求url this.host + '/areas/?area_id=' + this.form_address.city_id;
        # 1. 获取parent_id
        parent_id = request.GET.get('area_id')
        # 2. parent_id None 查询省,否则查询 市 区县
        if parent_id is None:
            # 3. 查询缓存 缓存没有查询db 并设置缓存
            province_catch = cache.get('province_catch')
            if province_catch is None:
                province_obj = Area.objects.filter(parent=None)
                province_catch = []
                for province in province_obj:
                    province_dict = {
                        'id': province.id,
                        'name': province.name
                    }
                    province_catch.append(province_dict)
                    #     设置缓存
                cache.set('province_catch', province_catch, 24 * 3600)
            return JsonResponse({'code': 0, 'province_list': province_catch})

        else:
            try:
                province_catch = cache.get('city_%s' % parent_id)
            except Exception as e:
                print(e)
            if province_catch is None:
                try:
                    province_obj = Area.objects.get(id=parent_id)
                    # 查询区 县
                    cities = province_obj.subs.all()
                except Exception as e:
                    return JsonResponse({'code': 0, 'subs': []})
                province_catch = []
                for city in cities:
                    province_catch.append({
                        'id': city.id,
                        'name': city.name
                    })
                # 设置缓存
                cache.set('city_%s' % parent_id, province_catch, 24 * 3600)
                return JsonResponse({'code': 0, 'subs': province_catch})
            else:
                return JsonResponse({'code': 0, 'subs': province_catch})